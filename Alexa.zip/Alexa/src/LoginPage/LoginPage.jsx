import React from 'react';
import { Link } from 'react-router-dom';
import { Redirect } from 'react-router'

import { connect } from 'react-redux';
import { alertActions } from '../_actions';
import { userActions } from '../_actions';

class LoginPage extends React.Component {
    constructor(props) {
        super(props);

        // reset login status
       // this.props.dispatch(userActions.logout());        
        this.state = {
            username: '',
            password: '',
            submitted: false,
            loading:false,
            loaded:false            
        };

        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleChange(e) {
        const { name, value } = e.target;
        this.setState({ [name]: value });
    }

    componentWillReceiveProps(nextProps) {
        console.log('authentication -' +JSON.stringify(nextProps.authentication));
        if(nextProps.authentication != null && nextProps.authentication.loggingIn != '')
        {
            this.setState({loading:nextProps.authentication.loggingIn});
        }

        if(nextProps.authentication != null && nextProps.authentication.loggedIn)
        {            
           // this.setState({loaded:nextProps.authentication.loggedIn});
            location.href="/";
        }
        
    }
    handleSubmit(e) {
        e.preventDefault();

        this.setState({ submitted: true });
        const { username, password } = this.state;
        const { dispatch } = this.props;
        if (username && password) {
            dispatch(userActions.login(username.trim().toLowerCase(), password));
        }
    }

    render() {
        const { authentication,alert } = this.props;       
        const { username, password, submitted,loaded,loading } = this.state;
        return (           
       <div className="col-sm-6 col-sm-offset-3" style={{marginTop:'10%'}}>
       {}
       <div className="panel panel-default" >
                 <div className="panel-heading"><h2>My Short Stories - Login</h2></div>
                <div className="panel-body">
                <form name="form" onSubmit={this.handleSubmit}>
                    <div className={'form-group' + (submitted && !username ? ' has-error' : '')}>
                        <label htmlFor="username">User Name (Email):</label>
                        <input type="text" className="form-control" name="username" value={username} onChange={this.handleChange} />
                        {submitted && !username &&
                            <div className="help-block">Username is required</div>
                        }
                    </div>
                    <div className={'form-group' + (submitted && !password ? ' has-error' : '')}>
                        <label htmlFor="password">Password:</label>
                        <input type="password" className="form-control" name="password" value={password} onChange={this.handleChange} />
                        {submitted && !password &&
                            <div className="help-block">Password is required</div>
                        }
                    </div>
                    <div className="form-group">
                         {alert.message &&
                            <div className={`alert ${alert.type}`}>{alert.message}</div>
                        }
                        <button className="btn btn-primary">Login</button>
                        {loading &&
                            <img src="data:image/gif;base64,R0lGODlhEAAQAPIAAP///wAAAMLCwkJCQgAAAGJiYoKCgpKSkiH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAADMwi63P4wyklrE2MIOggZnAdOmGYJRbExwroUmcG2LmDEwnHQLVsYOd2mBzkYDAdKa+dIAAAh+QQJCgAAACwAAAAAEAAQAAADNAi63P5OjCEgG4QMu7DmikRxQlFUYDEZIGBMRVsaqHwctXXf7WEYB4Ag1xjihkMZsiUkKhIAIfkECQoAAAAsAAAAABAAEAAAAzYIujIjK8pByJDMlFYvBoVjHA70GU7xSUJhmKtwHPAKzLO9HMaoKwJZ7Rf8AYPDDzKpZBqfvwQAIfkECQoAAAAsAAAAABAAEAAAAzMIumIlK8oyhpHsnFZfhYumCYUhDAQxRIdhHBGqRoKw0R8DYlJd8z0fMDgsGo/IpHI5TAAAIfkECQoAAAAsAAAAABAAEAAAAzIIunInK0rnZBTwGPNMgQwmdsNgXGJUlIWEuR5oWUIpz8pAEAMe6TwfwyYsGo/IpFKSAAAh+QQJCgAAACwAAAAAEAAQAAADMwi6IMKQORfjdOe82p4wGccc4CEuQradylesojEMBgsUc2G7sDX3lQGBMLAJibufbSlKAAAh+QQJCgAAACwAAAAAEAAQAAADMgi63P7wCRHZnFVdmgHu2nFwlWCI3WGc3TSWhUFGxTAUkGCbtgENBMJAEJsxgMLWzpEAACH5BAkKAAAALAAAAAAQABAAAAMyCLrc/jDKSatlQtScKdceCAjDII7HcQ4EMTCpyrCuUBjCYRgHVtqlAiB1YhiCnlsRkAAAOwAAAAAAAAAAAA==" />
                        }
                        <Link to="/register" className="btn btn-link">Register (New User)</Link>
                        <div className="alert alert-info" style={{marginTop : "5px"}}>
                            Watch youtube for instructions : <a target="_blank" href="https://www.youtube.com/watch?v=D_c9ankOBqM&t=65s"> Link</a>

                        </div>
                        <div className="alert alert-warning" style={{marginTop : "5px"}}>Password reset or any other queries contact <u>sree.sow.sainath@gmail.com</u> </div>
                        
                    </div>
                </form>
                </div>
            </div>     
         </div>
        );
    }
}

function mapStateToProps(state) {   
    return {
        authentication : state.authentication,
        alert:state.alert
    };
}

const connectedLoginPage = connect(mapStateToProps)(LoginPage);
export { connectedLoginPage as LoginPage }; 