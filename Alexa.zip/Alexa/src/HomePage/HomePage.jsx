import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import {Global} from '../_helpers/global';
import { userActions } from '../_actions';

class HomePage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            newstory: {
                Title: '',
                Category: '',
                Story: ''          
            },
            selectedAudio:'',
             submitted: false,
             editIndex:-1
        };
        this.handleChange = this.handleChange.bind(this);               
    }

   componentDidMount() {
       this.props.dispatch(userActions.getAllStories());       
    }



    handleStory(e,story,index) {
       this.refs.divStory.style.display="block";
       this.setState({
            newstory: story,
            editIndex:index
        });
    
    }

    onClick(event) {
        this.setState({editIndex:-1,newstory:{
            Title: '',
            Category: '',
            Story: ''          
        },submitted: false});
        this.refs.divStory.style.display="block";
    }

    onaudioClick(event)
    {
        event.preventDefault();
        if(this.refs.divaudio.style.display == "block")
            this.refs.divaudio.style.display="none";
        else
            this.refs.divaudio.style.display="block";
    }

    onCancel(event) {
        event.preventDefault();
        this.refs.divStory.style.display="none";
    }
    
    handleAddUpdateStory(event)
    {
        return (e) => this.props.dispatch(userActions.addStory(id));
    }

    handleChange(event) {      
        const { name, value } = event.target;
        const { newstory } = this.state;
        this.setState({
            newstory: {
                ...newstory,
                [name]: value
            }
        });
       
    }

    handleAudioChange(event) {      
        const { name, value } = event.target;
     /*    console.log(event.target.options[event.target.selectedIndex].value);
        console.log(event.target.options[event.target.selectedIndex].text); */
        const { selectedAudio } = this.state;
        this.setState({selectedAudio:event.target.options[event.target.selectedIndex]});
        //.document.getElementById("audioctl").src=event.target.options[event.target.selectedIndex].value;
        document.getElementById('audioctl').innerHTML = '<audio controlsList="nodownload" style="width:100%;max-width:300px" id="audio-player" controls="controls" src="'+ event.target.options[event.target.selectedIndex].value + '" type="audio/mpeg"/>';
    }

    handleSubmit(event,param) {

        event.preventDefault();
     /*    if(param =="d" && !confirm('Are you want to delete story?'))
         return; */        

        this.setState({ submitted: true });
        const { newstory } = this.state;
        const { dispatch } = this.props;
        var allstories = this.props.allstories;       
        if (newstory.Title && newstory.Category && newstory.Story) {
            console.log("param -" + param);
            if(param == "i" && this.state.editIndex >=0)
            {
                allstories.items[this.state.editIndex] = newstory;
                
            }
            else if(param == "d" && this.state.editIndex >=0)
            {
                allstories.items.splice(this.state.editIndex,1);
                
            }
            else{
             allstories.items.push(newstory);
            }
            dispatch(userActions.addStory(allstories.items));
            this.refs.divStory.style.display="none";
            this.setState({editIndex:-1,newstory:{
                Title: '',
                Category: '',
                Story: ''          
            },submitted: false});
        }
    }

    render() {        
        const { registering  } = this.props;
        const { user, allstories } = this.props;
        const { newstory, submitted } = this.state;
        let loggedinUser= JSON.parse(localStorage.getItem('user'));
        
var SOUNDS = [
    { "name": "birds", "url": 'https://s3.amazonaws.com/myshortstories/birds.mp3' },
    { "name": "angelic_sound", "url": 'https://s3.amazonaws.com/myshortstories/angelic_sound.mp3' },
    { "name": "bounce", "url": 'https://s3.amazonaws.com/myshortstories/bounce.mp3' },
    { "name": "cartoon_arrow", "url": 'https://s3.amazonaws.com/myshortstories/cartoon_arrow.mp3' },
    { "name": "cartoon_bite", "url": 'https://s3.amazonaws.com/myshortstories/cartoon_bite.mp3' },
    { "name": "cartoon_spin", "url": 'https://s3.amazonaws.com/myshortstories/cartoon_spin.mp3' },
    { "name": "cartoon_villain_laughter", "url": 'https://s3.amazonaws.com/myshortstories/cartoon_villain_laughter.mp3' },
    { "name": "chimes", "url": 'https://s3.amazonaws.com/myshortstories/chimes.mp3' },
    { "name": "cricket", "url": 'https://s3.amazonaws.com/myshortstories/cricket.mp3' },
    { "name": "fantasy", "url": 'https://s3.amazonaws.com/myshortstories/fantasy.mp3' },
    { "name": "guitar_tada", "url": 'https://s3.amazonaws.com/myshortstories/guitar_tada.mp3' },
    { "name": "magic", "url": 'https://s3.amazonaws.com/myshortstories/magic.mp3' },
    { "name": "magic_wand", "url": 'https://s3.amazonaws.com/myshortstories/magic_wand.mp3' },
    { "name": "magic_mallet", "url": 'https://s3.amazonaws.com/myshortstories/magic_mallet.mp3' },
    { "name": "rain", "url": 'https://s3.amazonaws.com/myshortstories/rain.mp3' },
    { "name": "thunder", "url": 'https://s3.amazonaws.com/myshortstories/thunder.mp3' },
    { "name": "tada", "url": 'https://s3.amazonaws.com/myshortstories/tada.mp3' },
    { "name": "twilight_tale", "url": 'https://s3.amazonaws.com/myshortstories/twilight_tale.mp3' },
    { "name": "whistle", "url": 'https://s3.amazonaws.com/myshortstories/whistle.mp3' },
    { "name": "wind", "url": 'https://s3.amazonaws.com/myshortstories/wind.mp3' },
{ "name": "applause", "url": 'https://s3.amazonaws.com/myshortstories/applause.mp3' },
{ "name": "laugh", "url": 'https://s3.amazonaws.com/myshortstories/laugh.mp3' },
{ "name": "crowd_laugh", "url": 'https://s3.amazonaws.com/myshortstories/crowd_laugh.mp3' }
];

        return (
            
            <div>
            <nav className="navbar navbar-default">
                    <div className="container-fluid">
                        <div className="navbar-header">
                        <a className="navbar-brand" href="#">My Short Stories</a>
                        </div>
                        <ul className="nav navbar-nav">
                            <li className="active"><a href="#">Home</a></li>                        
                            <li className="active"><Link to="/login">Logout</Link></li>                        
                        </ul>                    
                    </div>
            </nav>
            <div>
            <div className="alert alert-danger" role="alert">
                 Important : Please note the email '{loggedinUser.Email}' used here should be same as the amazon login email used for alexa device.
            </div>
             <button className="btn btn-primary" onClick={(e)=>this.onClick(e)}>Add Your Story</button>
               {/*  {allstories!=null && allstories.items !=null && allstories.items.length <5? 
                <button className="btn btn-primary" onClick={(e)=>this.onClick(e)}>Add Stories</button> :
                <div>
                <button className="btn btn-primary" disabled onClick={(e)=>this.onClick(e)}>Add Stories</button>
                <div className="alert alert-warning" role="alert">
                    Restricted to 5 stories initially.
                </div>
                </div>
                } */}
                
            </div>
            <div ref="divStory" style={{display:"none", marginTop:"10px",boxShadow:"10px 10px 5px grey"}} className="panel panel-default">
                    <div className="panel-heading">Add/Edit Story</div>
                    <div className="panel-body">
                    <form name="form">
                    <div className={'form-group' + (submitted && !newstory.Title ? ' has-error' : '')}>
                        <label htmlFor="Title">Title(max 100 characters)</label>
                        <input type="text" maxLength="100" className="form-control" name="Title" value={newstory.Title} onChange={this.handleChange} />
                        <div className="alert alert-warning" role="alert">
                            <h5><b>NOTE: You can invoke story by title from alexa by saying, Alexa, ask my short stories to read story '{newstory.Title === '' ? 'You story title' : newstory.Title}' </b></h5>
                           <h4> TIPS for story titles :</h4>
                            <ul style={{listStyleType:"disc"}}>
                                <li> Use unique story titles for each story </li>
                                <li>      Have at least two words </li>
                                <li>      Avoid lengthy story titles </li>
                                <li>          Avoid keywords like 'story', 'tale'</li>
                                <li>       Avoid name of a person </li>
                            </ul>
                        </div>
                        {submitted && !newstory.Title &&
                            <div className="help-block">Title is required</div>
                        }
                    </div>
                    <div className={'form-group' + (submitted && !newstory.Category ? ' has-error' : '')}>
                        <label htmlFor="category">Category</label>
                        <select  className="form-control" name="Category" value={newstory.Category} onChange={this.handleChange}>
                                        <option value="Select">Select</option>
                                        <option value="Folk">Folk</option>
                                        <option value="Fairy Tale">Fairy Tale</option>
                                        <option value="Parable">Parable</option>
                                        <option value="Mythical">Mythical</option>
                                        <option value="Personal">Personal</option>
                                        </select>                      
                        {submitted && !newstory.Category &&
                            <div className="help-block">Category is required</div>
                        }
                    </div>
                    <div className={'form-group' + (submitted && !newstory.Story ? ' has-error' : '')}>
                        <label htmlFor="storytext">Story (max 5000 characters)</label>
                        <textarea rows="10" maxLength="5000" cols="50" className="form-control" name="Story" value={newstory.Story} onChange={this.handleChange} />
                        {submitted && !newstory.Story &&
                            <div className="help-block">story is required</div>
                        }
                    </div>          
                    <button className="btn btn-primary" style={{whiteSpace:"normal"}} onClick={(e)=>this.onaudioClick(e)}>
                    Click here to see how you can add audio and speechcons to your stories!</button>           
                    <br/>
                    <div ref="divaudio" style={{display:"none", marginTop:"10px",boxShadow:"5px 5px 5px grey"}} className="panel-group">
                    <div className="panel panel-primary">                                                
                          <div className="panel-body">
                         
                             To include a speechcon in your story, use the <pre>&lt;say-as interpret-as="interjection"&gt; abracadabra!&lt;/say-as&gt;</pre>
                             Check the list of available speechcons here : <a href='https://developer.amazon.com/docs/custom-skills/speechcon-reference-interjections-english-us.html' target="_blank">Click here</a>
                             <br/><br/>
                             To include audio clip in your story add this tag $$audio_clip_name$$ where audio_clip_name can be one of the following
                             <br/>
                             <b>NOTE: You can use only max for 4 audio tags in a story.</b>
                             <div className="container">
                                <div className="row">
                                    <div className="col-sm-3">
                                    <select  className="form-control" name="AudioSounds" value={this.state.selectedAudio.value} onChange={(event)=>this.handleAudioChange(event)}>
                             <option value="Select">--Select Audio--</option>
                             {SOUNDS.map((key,index) =>
                             {
                                return <option key={index} value={key.url} >{key.name}</option>
                             })}
                             </select> 
                                    
                                    </div>
                                    <div className="col-sm-8">
                                    <span id="audioctl"></span>
                                     <div style={{verticalAlign:'top',fontWeight:'bold'}}> {this.state.selectedAudio === '' ?  '' :  'Use tag, $$' + this.state.selectedAudio.text + '$$'} </div>
                                    </div>
                                </div>
                                
                                </div>
                                <br/>
                               Here is sample story with speechcons and audio tags:
                                <pre>
                                
                                $$fantasy$$ &lt;say-as interpret-as="interjection"&gt;vroom!&lt;/say-as&gt; Once a Chinese emperor organized a race for animals.<br/>
                                 The first twelve animals to finish were to be given a place in the Chinese Zodiac. The cat and the rat, both lazy creatures, asked the ox to wake them on the day of the race.<br/>
                                 $$whistle$$ The day arrived. The ox tried to wake them up, but could not succeed. <br/>
                                 The race was about to start.$$applause$$ The ox coaxed them onto his back and started running. <br/>
                                 The rat woke up when the ox was crossing the last hurdle, a river. The rat pushed the cat off the ox's back. When the ox reached the other side, the rat jumped off and scampered to victory, just ahead of the ox. <br/>
                                 The tiger came third, crossing the river by using the backs of the animals swimming across as stepping stones.<br/>
                                 So the twelve-year cycle of the Chinese Zodiac begins with the rat After him come the ox, tiger, rabbit dragon snake, horse, goat, monkey, rooster, dog and pig. The cat, however, has no place in the zodiac. <br/>
                                 So all the cats still remember the humiliatior heaped on their ancestor by a tricky rat and thus chase the rats to punish them.$$crowd_laugh$$
                                
                                    </pre>                                             
                        </div>
                    </div>
                    </div>
                    <br/>
                    <div className="form-group">
                        <button className="btn btn-primary" onClick={(e) => this.handleSubmit(e,'i')} style={{marginRight:"16px"}}>Submit</button>
                        {registering && 
                            <img src="data:image/gif;base64,R0lGODlhEAAQAPIAAP///wAAAMLCwkJCQgAAAGJiYoKCgpKSkiH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAADMwi63P4wyklrE2MIOggZnAdOmGYJRbExwroUmcG2LmDEwnHQLVsYOd2mBzkYDAdKa+dIAAAh+QQJCgAAACwAAAAAEAAQAAADNAi63P5OjCEgG4QMu7DmikRxQlFUYDEZIGBMRVsaqHwctXXf7WEYB4Ag1xjihkMZsiUkKhIAIfkECQoAAAAsAAAAABAAEAAAAzYIujIjK8pByJDMlFYvBoVjHA70GU7xSUJhmKtwHPAKzLO9HMaoKwJZ7Rf8AYPDDzKpZBqfvwQAIfkECQoAAAAsAAAAABAAEAAAAzMIumIlK8oyhpHsnFZfhYumCYUhDAQxRIdhHBGqRoKw0R8DYlJd8z0fMDgsGo/IpHI5TAAAIfkECQoAAAAsAAAAABAAEAAAAzIIunInK0rnZBTwGPNMgQwmdsNgXGJUlIWEuR5oWUIpz8pAEAMe6TwfwyYsGo/IpFKSAAAh+QQJCgAAACwAAAAAEAAQAAADMwi6IMKQORfjdOe82p4wGccc4CEuQradylesojEMBgsUc2G7sDX3lQGBMLAJibufbSlKAAAh+QQJCgAAACwAAAAAEAAQAAADMgi63P7wCRHZnFVdmgHu2nFwlWCI3WGc3TSWhUFGxTAUkGCbtgENBMJAEJsxgMLWzpEAACH5BAkKAAAALAAAAAAQABAAAAMyCLrc/jDKSatlQtScKdceCAjDII7HcQ4EMTCpyrCuUBjCYRgHVtqlAiB1YhiCnlsRkAAAOwAAAAAAAAAAAA==" />
                        }
                        <button className="btn btn-primary" onClick={(e)=>this.onCancel(e)} style={{marginRight:"16px"}}>Cancel</button>
                        {this.state.editIndex != -1 ?
                        <button className="btn btn-primary" onClick={(e)=>this.handleSubmit(e,'d')}>Delete</button> : <br/>
                        }
                    </div>
                </form>                        
                    </div>
                </div>
            <h2>My Stories :</h2>               
                {allstories.loading && <em>Loading Stories...</em>}
                {allstories.error && <span className="text-danger">ERROR: {allstories.error}</span>}                
                {allstories.items &&
                    <div>
                         {allstories.items.map((story, index) =>
                         <div  key={index} className="container col-md-3 col-sm-6">
                            <div style={{boxShadow:"5px 5px 5px grey"}} className="panel panel-primary">
                                <div className="panel-heading">
                                 <h4>   <a href="#" onClick={(e) => this.handleStory(e,story,index)} style={{color:"white",
                                 textDecoration:"underline"} }> {story.Title} </a>                                   
                                 </h4>
                                </div>                                                                                                                   
                               <div className="panel-body" style={{width:"100%", height:"150px",textOverflow:"ellipsis",overflow:"hidden"}}>
                                    {story.Story}
                               </div>                                             
                            </div>
                        </div>
                         )}                  
                   </div>
                }

                
            </div>
        );
    }
}

function mapStateToProps(state) {
    const { allstories, authentication } = state;
    const { user } = authentication;
    return {
        user,
        allstories
    };
}

const connectedHomePage = connect(mapStateToProps)(HomePage);
export { connectedHomePage as HomePage };