import { userConstants } from '../_constants';

export function story(state = {}, action) {
  switch (action.type) {
    case userConstants.STORY_REQUEST:
      return { registering: true };
    case userConstants.STORY_SUCCESS:
      return {};
    case userConstants.STORY_FAILURE:
      return {};
    default:
      return state
  }
}