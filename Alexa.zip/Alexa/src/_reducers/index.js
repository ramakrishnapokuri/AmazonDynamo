import { combineReducers } from 'redux';

import { authentication } from './authentication.reducer';
import { registration } from './registration.reducer';
import { story } from './story.reducer';
import { allstories } from './allstories.reducer';
import { alert } from './alert.reducer';

const rootReducer = combineReducers({
  authentication,
  registration,
  story,
  allstories,
  alert
});

export default rootReducer;