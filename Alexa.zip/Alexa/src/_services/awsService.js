import AWS, { config } from 'aws-sdk';
import {Global} from  '../_helpers/global'; 
/* AWS.config.update({
    region: "us-west-2"
  }); */
  let loggedinUser=JSON.parse(localStorage.getItem('user'));

  AWS.config.update({
    accessKeyId: "AKIAIIDHVO7MXU3BESVA",
    secretAccessKey: "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",
    "region": "us-east-1"  
});
var docClient = new AWS.DynamoDB.DocumentClient();
const usertable = "User";
export const awsService = {
    checkUserExistsandRegister,
    login,
    getAllStories ,
    addStory 
};

function addStory(story,callback)
{    
    console.log('new story adding -' + JSON.stringify(story) );
   const params = {
        TableName:usertable,
        Key:{
            "Email": loggedinUser.Email            
        },
        UpdateExpression: "set Stories=:stories_val",
        ExpressionAttributeValues:{
            ":stories_val": story
        },
        ReturnValues:"UPDATED_NEW"
    }   
    
    docClient.update(params, function(err, data) {
        callback(err,data);         
    });
};

function getAllStories(callback)
{ 
   
    var params = {
        TableName: usertable ,
        ProjectionExpression: "Stories",
        FilterExpression: "#email = :email_val",
        ExpressionAttributeNames: {
            "#email": "Email",
        },
        ExpressionAttributeValues: { ":email_val": loggedinUser.Email }      
    };

    docClient.scan(params, function(err, data) {
        console.log(data.Items);
        console.log('Error -' +err);
        if (err) {
            console.error("Unable to query. Error:", JSON.stringify(err, null, 2));
        } 
        else if(data.Items.length > 0)
        {         
            console.log('Aws service getall stories -' +JSON.stringify(data.Items[0].Stories));
            callback(err,data.Items[0].Stories);            
        }
        else
        {
            callback("Unauthorised",data);
        }
    });
}

function login(username, password,callback)
{
    var params = {
        TableName: usertable,        
        FilterExpression: "#email = :useremail and #password = :userPassword",
        ExpressionAttributeNames: {
            "#email": "Email",
            "#password": "Password"
        },
        ExpressionAttributeValues: {
             ":useremail": username,
             ":userPassword": password

        }
    };

    docClient.scan(params, function(err, data) {
        console.log(data.Items);
        console.log('Error -' +err);
        if (err) {
            console.error("Unable to query. Error:", JSON.stringify(err, null, 2));
        } 
        else if(data.Items.length > 0)
        {   
           var user=data.Items[0];
           localStorage.setItem('user',JSON.stringify(user));                       
           // console.log(user.Email);
           // Global.Email=user.Email;
           //  Global.UserName=user.FirstName +" "  + user.LastName;
           callback(err,data.Items);            
        }
        else
        {
            callback("Unauthorised",data);
        }
    });
}

function registerUser(user,callback)
{    
   const params = {
        TableName:usertable,
        Item:{            
            "Email": user.username,
            "FirstName": user.firstName,
            "LastName":user.lastName,
            "Password":user.password,
            "Stories":[]            
            }
        }       
    
    docClient.put(params, function(err, data) {
        callback(err,data);         
    });
};

function checkUserExistsandRegister(user,callback)
{   
    var returnValue=false;

    var params = {
        TableName: usertable,
        ProjectionExpression: "ID",
        FilterExpression: "#email = :useremail",
        ExpressionAttributeNames: {
            "#email": "Email",
        },
        ExpressionAttributeValues: {
             ":useremail": user.username
        }
    };

    docClient.scan(params, function(err, data) {
        console.log(data.Items.length);
        console.log('Error -' +err);
        if (err) {
            console.error("Unable to query. Error:", JSON.stringify(err, null, 2));
        } 
        else if(data.Items.length == 0)
        {
            registerUser(user,callback);
        }
        else
        {
            callback("User already exists",data);
        }
    });

    return returnValue;
}

function getAll() {    
    const params = {
        TableName:usertable        
        }       
    
    docClient.get(params, function(err, data) {
        callback(err,data);         
    });
}