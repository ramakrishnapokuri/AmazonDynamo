import React from 'react';
import { Route, Redirect } from 'react-router-dom';
import {Global} from '../_helpers/global';

let user=JSON.parse(localStorage.getItem('user'));
console.log(user != null &&  user.Email.length !=0);
export const PrivateRoute = ({ component: Component, ...rest }) => (    
    <Route {...rest} render={props => (
        user != null &&  user.Email.length !=0
            ? <Component {...props} />
            : <Redirect to={{ pathname: '/login', state: { from: props.location } }} />
    )} />
)