export const Global={
    UserName : '',
    Email : ''
};