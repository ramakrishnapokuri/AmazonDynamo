import { userConstants } from '../_constants';
import { userService } from '../_services';
import { alertActions } from './';
import { history } from '../_helpers';
import {awsService} from '../_services';

export const userActions = {
    login,
    logout,
    register,
    getAllStories,
    addStory    
};

function login(username, password) {
    
    return dispatch => {
        dispatch(request({ username }));
        awsService.login(username, password,function(err, data) {  
            console.log('user action -' + err);         
            if (err)
           {
                dispatch(failure(err));
                dispatch(alertActions.error(err));
           }
            else
            {
                console.log('redirect');
                dispatch(success(data));
               // location.href="/";
               //history.push('/');              
            }
        });       
    };

    function request(user) { return { type: userConstants.LOGIN_REQUEST, user } }
    function success(user) { return { type: userConstants.LOGIN_SUCCESS, user } }
    function failure(error) { return { type: userConstants.LOGIN_FAILURE, error } }
}

function addStory(story)
{
    console.log("user actions add story method -" + JSON.stringify(story));
    return dispatch => {
        dispatch(request({ story }));
        awsService.addStory(story,function(err, data) {           
            if (err)
           {
                dispatch(failure(err));
                dispatch(alertActions.error(err));
           }
            else
            {                
                dispatch(success()); 
                dispatch(alertActions.success('Story added/updated successfully')); 
                dispatch(getAllStories) ;                      
            }
        });       
    };

    function request(story) { return { type: userConstants.STORY_REQUEST, story } }
    function success(story) { return { type: userConstants.STORY_SUCCESS, story } }
    function failure(error) { return { type: userConstants.STORY_FAILURE, error } }

}

function logout() {
    userService.logout();
    return { type: userConstants.LOGOUT };
}

function register(user) {
    return dispatch => {
        dispatch(request(user));
        awsService.checkUserExistsandRegister(user,function(err, data) {
            console.log('User actin Error -' + err);
            if (err)
           {
                dispatch(failure(err));
                dispatch(alertActions.error(err));
           }
            else
            {
                dispatch(success());
                history.push('/login');
                dispatch(alertActions.success('Registration successful'));
            }
        });       
    };

    function request(user) { return { type: userConstants.REGISTER_REQUEST, user } }
    function success(user) { return { type: userConstants.REGISTER_SUCCESS, user } }
    function failure(error) { return { type: userConstants.REGISTER_FAILURE, error } }
}

function getAllStories() {
    return dispatch => {
        dispatch(request());

        awsService.getAllStories(function(err, data) {
          if (err)
           {
              dispatch(failure(err));
           }
            else
            {
                console.log(data);
                dispatch(success(data));
            }
        });       
            
    };

    function request() { return { type: userConstants.GETALL_REQUEST } }
    function success(stories) { return { type: userConstants.GETALL_SUCCESS, stories } }
    function failure(error) { return { type: userConstants.GETALL_FAILURE, error } }
}

// prefixed function name with underscore because delete is a reserved word in javascript
function _delete(id) {
    return dispatch => {
        dispatch(request(id));

        userService.delete(id)
            .then(
                user => { 
                    dispatch(success(id));
                },
                error => {
                    dispatch(failure(id, error));
                }
            );
    };

    function request(id) { return { type: userConstants.DELETE_REQUEST, id } }
    function success(id) { return { type: userConstants.DELETE_SUCCESS, id } }
    function failure(id, error) { return { type: userConstants.DELETE_FAILURE, id, error } }
}