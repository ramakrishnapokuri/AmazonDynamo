import AWS from 'aws-sdk';
AWS.config.update({
    region: "us-west-2"
  });
var docClient = new AWS.DynamoDB.DocumentClient();
export const awsService = {
    registertoDynamoDB
};
function registertoDynamoDB(user)
{
    const table = "User";
    const params = {
        TableName:table,
        Item:{
            "email": user.username,
            "firstName": user.firstName,
            "lastName":user.lastName,
            "password":user.password            
            }
        }    
    
    console.log("Adding a new item...");
    docClient.put(params, function(err, data) {
        if (err) {
            console.error("Unable to add item. Error JSON:", JSON.stringify(err, null, 2));
        } else {
             // respond 200 OK
             resolve({ ok: true, json: () => ({}) });
             return
        }
    });
};